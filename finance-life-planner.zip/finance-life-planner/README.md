# Finance Life Planner

Your personal CFO — a comprehensive financial planning app with net worth tracking, retirement simulation, debt management, life scenario planning, and an AI financial advisor.

## Features

- **Dashboard** — Net worth projection, goal progress, health score
- **Snapshot** — Profile, income, financial health overview
- **Expenses** — 24 expense categories with live pie chart breakdown
- **Assets** — CRUD asset tracker (cash, investments, retirement, property, crypto)
- **Debts** — Credit cards, loans, mortgage management with payoff strategies
- **Retirement Goal** — Gap analysis, required portfolio, monthly target calculator
- **Retire Predictor** — Conservative / base / aggressive retirement age scenarios
- **Scenarios** — Life event planning (house, business, kids, relocation) — combinable
- **Lifestyle** — 6 lifestyle templates + add-on cost planner with FIRE number
- **Roadmap** — Interactive goal timeline with milestones
- **AI Planner** — Claude-powered financial advisor chat (requires your own API key)

## Deploy on Vercel

### Option 1 — Vercel CLI
```bash
npm i -g vercel
vercel
```

### Option 2 — Vercel Dashboard
1. Push this repo to GitHub
2. Go to [vercel.com](https://vercel.com) → New Project
3. Import your GitHub repo
4. Click **Deploy** — no build settings needed (pure static HTML)

## Local Development

Just open `index.html` in your browser — no build step required.

```bash
# Or use any static server:
npx serve .
```

## AI Advisor

The AI Planner page requires a Claude API key (from [console.anthropic.com](https://console.anthropic.com)).  
Enter your key in the app — it's stored locally in your browser and never sent anywhere except Anthropic's API.

## Data Storage

All your financial data is saved to your browser's `localStorage` — it stays on your device and persists between sessions. No server, no account required.

## Tech Stack

- React 18 (CDN, no build step)
- Recharts 2.12.7 (CDN)
- Vanilla CSS with CSS custom properties
- Claude API for AI features
